
    let currentIndex = 0;
    const slides = document.getElementById("slides");
    const totalSlides = slides.children.length;

    function moveSlide(step) {
      currentIndex = (currentIndex + step + totalSlides) % totalSlides;
      updateSlide();
    }

    function updateSlide() {
      slides.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    // Auto-play every 4s
    setInterval(() => {
      moveSlide(1);
    }, 4000);
